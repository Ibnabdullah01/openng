<?php
session_start();
 if(!(isset($_SESSION['admin']))){
  header("location: index.php");
  }



   include 'conn/conn.php'; 


if (isset($_POST['add'])) {

    //render files for upload
    $fname = mysqli_real_escape_string($db, trim($_POST['fname']));
    $lname = mysqli_real_escape_string($db, trim($_POST['lname']));
    $email = mysqli_real_escape_string($db, trim($_POST['email']));
    $Phone = mysqli_real_escape_string($db, trim($_POST['phone']));
 /*
    // pdf file upload
    $pass = mysqli_real_escape_string($db, trim($_FILES['pass']['name']));
    
    //pdf file size & type
    $pass_type = $_FILES['pass']['type'];
    $pass_size = $_FILES['pass']['size']; 

       // Define application constants
      define('MM_UPLOADPATH', 'save/');
      define('MM_MAXFILESIZE', 50000000);      // 5MB 

*/
    
    if(($fname != '') && ($lname != '') && ($email != '') && ($Phone != '')  ) {
/*
        if ((($pass_type == 'pdf') && ($pass_size > 0) && ($pass_size <= MM_MAXFILESIZE))) {
        if ($_FILES['file']['error'] == 0) {
          // Move the file to the target upload folder
          $target1 = MM_UPLOADPATH.basename($pass);
        $upload= move_uploaded_file($_FILES['pass']['tmp_name'], $target1);
          if ($upload) {
          }
        }

    }
*/
    $query = "INSERT INTO usr (fname, lname, email, phone  ) VALUES ('$fname', '$lname', '$email', '$Phone')";
    
    $result = mysqli_query($db, $query);
    
    $error="<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
               Record Upload Successful
            </div>";
            
    } else{
            $error="<div class='alert alert-danger alert-dismissable'>
                          <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                           Please, Enter All information to upload Record!
                    </div>";
           
    }
    
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add New Members</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Add New Members</h2>
                        <?php
                            if(isset($error)){
                                echo $error;
                            }
                        ?>
                        <form method="POST" class="register-form" id="register-form" action="home.php">

                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="fname" id="name" placeholder="First Name"/>
                            </div>
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="lname" id="name" placeholder="Last Name"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Email Address"/>
                            </div>
                            <div class="form-group">
                                <label for="phone"><i class="zmdi zmdi-phone"></i></label>
                                <input type="phone" name="phone" id="phone" placeholder="Phone Number"/>
                            </div>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-file"></i></label>
                                <input type="file" name="pass" id="re_pass"/>
                            </div>
                            
                            <div class="form-group form-button">
                                <input type="submit" name="add" id="signup" class="form-submit" value="Add Member"/>
                            </div>

                        </form>
                    </div>
                   
                </div>
            </div>
        </section>
    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>